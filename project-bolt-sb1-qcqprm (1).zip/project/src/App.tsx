{/* Previous imports remain the same */}

function App() {
  return (
    <div className="bg-black text-gray-100 min-h-screen">
      {/* Navigation remains the same */}

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1601362840469-51e4d8d58785?auto=format&fit=crop&q=80"
            alt="Luxury car interior with large display"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black via-black/70 to-black" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-zinc-800/20 via-black/40 to-black" />
        </div>
        
        {/* Rest of the component remains exactly the same */}
      </section>

      {/* Rest of the sections remain exactly the same */}
    </div>
  );
}

{/* Rest of the components remain exactly the same */}

export default App;